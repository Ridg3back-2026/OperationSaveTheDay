# Quick Reference Card - Dijkstra SDN Controller

## 🚀 Quick Start (3 Steps)

### Step 1: Start POX Controller
```bash
cd ~/pox
./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra
```
**Wait for:** `Dijkstra-based SDN Controller launched successfully`

### Step 2: Start Mininet (New Terminal)
```bash
sudo python3 ~/mininet_topology.py
```
**Wait for:** `mininet>` prompt

### Step 3: Test Connectivity
```bash
mininet> h1 ping -c 3 h2
```
**Expect:** 0% packet loss

---

## 🧪 Quick Tests

### Test Failover
```bash
# Terminal 3
curl -X POST http://localhost:8000/failure -d "a=3&b=2"

# Terminal 2 (Mininet)
mininet> h1 ping -c 5 h2
```

### Restore Link
```bash
curl -X POST http://localhost:8000/restore -d "a=3&b=2"
```

### Check Status
```bash
curl -X POST http://localhost:8000/status -d ""
```

---

## 🛑 Shutdown

```bash
# Mininet terminal
mininet> exit
sudo mn -c

# POX terminal
Ctrl+C
```

---

## 🔧 Emergency Cleanup

```bash
sudo mn -c
sudo killall controller
sudo fuser -k 6633/tcp
sudo fuser -k 8000/tcp
```

---

## 📊 Topology
```
    H1 (10.0.0.1)
         |
        S3
       /  \
     S2    S5  (Primary)  (Backup)
       \  /
        S4
         |
    H2 (10.0.0.2)
```

---

## 🎯 Expected Paths

- **Normal:** [3, 2, 4] (S3→S2→S4)
- **After S3-S2 failure:** [3, 5, 4] (S3→S5→S4)

---

## 📝 Common Commands

### View Flows
```bash
mininet> sh ovs-ofctl dump-flows s2
mininet> sh ovs-ofctl dump-flows s3
mininet> sh ovs-ofctl dump-flows s4
mininet> sh ovs-ofctl dump-flows s5
```

### View Topology
```bash
mininet> net
```

### Clear Flows
```bash
mininet> sh ovs-ofctl del-flows s2
mininet> sh ovs-ofctl del-flows s3
mininet> sh ovs-ofctl del-flows s4
mininet> sh ovs-ofctl del-flows s5
```

### Continuous Ping
```bash
mininet> h1 ping h2
# Ctrl+C to stop
```

---

## ⚠️ Troubleshooting One-Liners

**Port 6633 in use:**
```bash
sudo fuser -k 6633/tcp
```

**Port 8000 in use:**
```bash
sudo fuser -k 8000/tcp
```

**Switches not connecting:**
```bash
sudo mn -c && sudo killall controller
```

**Ping fails:**
```bash
# Check flows exist
mininet> sh ovs-ofctl dump-flows s3
# Restart if empty
```

---

## 🎓 What to Watch For

**POX Terminal Success Indicators:**
- ✅ "Dijkstra-based SDN Controller launched successfully"
- ✅ "Switch X connected" (4 times)
- ✅ "ADDED adjacency" (8 times)
- ✅ "Dijkstra found path: [3, 2, 4]"

**Failure Test Success:**
- ✅ POX shows "LINK FAILURE DETECTED: 3 <-> 2"
- ✅ POX shows "Dijkstra found path: [3, 5, 4]"
- ✅ Ping continues working

---

## 📱 File Locations

- **Controller:** `~/pox/pox/misc/controller_with_dijkstra.py`
- **Topology:** `~/mininet_topology.py`
- **POX:** `~/pox/pox.py`

---

## 🔄 Full Restart Sequence

```bash
# 1. Clean everything
sudo mn -c
sudo killall controller
sudo fuser -k 6633/tcp 8000/tcp

# 2. Start POX
cd ~/pox
./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra

# 3. Start Mininet (wait 3 seconds first!)
sudo python3 ~/mininet_topology.py

# 4. Test
mininet> h1 ping -c 3 h2
```

---

**Print this page for quick reference!**
