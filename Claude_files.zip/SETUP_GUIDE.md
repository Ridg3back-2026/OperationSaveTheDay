# Dijkstra SDN Controller - Setup & Execution Guide

## 📋 Prerequisites

- Mininet VM installed and running
- POX controller installed (typically in `~/pox`)
- Python 3.x
- Basic understanding of terminal commands

---

## 📁 Required Files

You need these two files:

1. **controller_with_dijkstra.py** - The POX controller with Dijkstra's algorithm
2. **mininet_topology.py** - The Mininet network topology script

---

## 🚀 Complete Setup Instructions

### Step 1: Install Files

**Option A: If files are in shared folder**
```bash
# Copy controller to POX directory
cp /media/sf_MININET_RESOURCES/controller_fixed_edge_ports.py ~/pox/pox/misc/controller_with_dijkstra.py

# Copy topology script to a working directory
cp /media/sf_MININET_RESOURCES/mininet_topology.py ~/
```

**Option B: Create files manually**

See the "File Contents" section at the end of this guide for the complete code.

### Step 2: Set Correct Permissions

```bash
# Set proper ownership and permissions
chown mininet:mininet ~/pox/pox/misc/controller_with_dijkstra.py
chmod 644 ~/pox/pox/misc/controller_with_dijkstra.py
chmod +x ~/mininet_topology.py
```

### Step 3: Verify Installation

```bash
# Check POX can see the controller
cd ~/pox
./pox.py --help | grep controller_with_dijkstra
# Should show misc.controller_with_dijkstra if installed correctly
```

---

## 🎯 Execution Steps

### Terminal 1: Start POX Controller

```bash
cd ~/pox
./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra
```

**Expected output:**
```
POX 0.7.0 (gar) / Copyright 2011-2020 James McCauley, et al.
INFO:misc.controller_with_dijkstra:External Failure API Server running on port 8000
INFO:misc.controller_with_dijkstra:Endpoints: /failure, /restore, /status
WARNING:version:Support for Python 3 is experimental.
INFO:core:POX 0.7.0 (gar) is up.
INFO:misc.controller_with_dijkstra:============================================================
INFO:misc.controller_with_dijkstra:Dijkstra-based SDN Controller launched successfully
INFO:misc.controller_with_dijkstra:============================================================
```

**Wait for this message before starting Mininet!**

### Terminal 2: Start Mininet Topology

**Open a new terminal window**, then:

```bash
cd ~
sudo python3 mininet_topology.py
```

**Expected output:**
```
* Adding controller
* Add switches
* Add hosts
* Add links
* Starting network
* Starting controllers
* Starting switches
* Running CLI
mininet>
```

**In Terminal 1 (POX)**, you should now see:
```
INFO:openflow.of_01:[00-00-00-00-00-04 1] connected
INFO:misc.controller_with_dijkstra:Switch 4 connected
INFO:openflow.of_01:[00-00-00-00-00-03 2] connected
INFO:misc.controller_with_dijkstra:Switch 3 connected
INFO:openflow.of_01:[00-00-00-00-00-05 3] connected
INFO:misc.controller_with_dijkstra:Switch 5 connected
INFO:openflow.of_01:[00-00-00-00-00-02 4] connected
INFO:misc.controller_with_dijkstra:Switch 2 connected
INFO:openflow.discovery:link detected: ...
INFO:misc.controller_with_dijkstra:ADDED adjacency: ...
INFO:misc.controller_with_dijkstra:Computing path from S3 to S4...
INFO:misc.controller_with_dijkstra:Dijkstra found path: [3, 2, 4] (length: 2)
INFO:misc.controller_with_dijkstra:Installing flows for path: [3, 2, 4]
```

---

## 🧪 Testing the System

### Test 1: Basic Connectivity

**In Terminal 2 (Mininet CLI):**
```bash
mininet> h1 ping -c 3 h2
```

**Expected result:**
```
PING 10.0.0.2 (10.0.0.2) 56(84) bytes of data.
64 bytes from 10.0.0.2: icmp_seq=1 ttl=64 time=X ms
64 bytes from 10.0.0.2: icmp_seq=2 ttl=64 time=X ms
64 bytes from 10.0.0.2: icmp_seq=3 ttl=64 time=X ms
--- 10.0.0.2 ping statistics ---
3 packets transmitted, 3 received, 0% packet loss
```

**✅ Success indicator:** 0% packet loss, traffic flows via **S3 → S2 → S4**

---

### Test 2: Link Failure (Dynamic Rerouting)

**Open Terminal 3**, then inject a failure:

```bash
curl -X POST http://localhost:8000/failure -d "a=3&b=2"
```

**Expected response:**
```
Failure injected on 3-2
```

**In Terminal 1 (POX), watch for:**
```
INFO:misc.controller_with_dijkstra:============================================================
INFO:misc.controller_with_dijkstra:LINK FAILURE DETECTED: 3 <-> 2
INFO:misc.controller_with_dijkstra:============================================================
INFO:misc.controller_with_dijkstra:Recomputing path to avoid failed link...
INFO:misc.controller_with_dijkstra:Computing path from S3 to S4...
INFO:misc.controller_with_dijkstra:Dijkstra found path: [3, 5, 4] (length: 2)
```

**Back in Terminal 2 (Mininet):**
```bash
mininet> h1 ping -c 5 h2
```

**Expected result:**
```
5 packets transmitted, 5 received, 0% packet loss
```

**✅ Success indicator:** Traffic automatically rerouted via **S3 → S5 → S4** (backup path)

---

### Test 3: Link Restoration

**In Terminal 3:**
```bash
curl -X POST http://localhost:8000/restore -d "a=3&b=2"
```

**Expected response:**
```
Link restored on 3-2
```

**In Terminal 1 (POX), watch for:**
```
INFO:misc.controller_with_dijkstra:============================================================
INFO:misc.controller_with_dijkstra:LINK RESTORED: 3 <-> 2
INFO:misc.controller_with_dijkstra:============================================================
INFO:misc.controller_with_dijkstra:Recomputing optimal path...
INFO:misc.controller_with_dijkstra:Computing path from S3 to S4...
INFO:misc.controller_with_dijkstra:Dijkstra found path: [3, 2, 4] (length: 2)
```

**In Terminal 2 (Mininet):**
```bash
mininet> h1 ping -c 3 h2
```

**✅ Success indicator:** Traffic returns to primary path **S3 → S2 → S4**

---

### Test 4: Check Network Status

**In Terminal 3:**
```bash
curl -X POST http://localhost:8000/status -d ""
```

**Expected response:**
```
{'adjacency': '{3: {2: 2, 5: 3}, 2: {3: 1, 4: 2}, ...}', 
 'failed_links': 'set()', 
 'connections': [2, 3, 4, 5]}
```

---

## 🔍 Debugging Commands

### Check Flow Tables

**In Mininet CLI:**
```bash
mininet> sh ovs-ofctl dump-flows s2
mininet> sh ovs-ofctl dump-flows s3
mininet> sh ovs-ofctl dump-flows s4
mininet> sh ovs-ofctl dump-flows s5
```

### Check Switch Ports

```bash
mininet> sh ovs-ofctl show s3
```

### View Network Topology

```bash
mininet> net
```

**Expected output:**
```
h1 h1-eth0:s3-eth1
h2 h2-eth0:s4-eth2
s2 lo:  s2-eth1:s3-eth2 s2-eth2:s4-eth1
s3 lo:  s3-eth1:h1-eth0 s3-eth2:s2-eth1 s3-eth3:s5-eth1
s4 lo:  s4-eth1:s2-eth2 s4-eth2:h2-eth0 s4-eth3:s5-eth2
s5 lo:  s5-eth1:s3-eth3 s5-eth2:s4-eth3
c0
```

### Clear All Flows (if needed)

```bash
mininet> sh ovs-ofctl del-flows s2
mininet> sh ovs-ofctl del-flows s3
mininet> sh ovs-ofctl del-flows s4
mininet> sh ovs-ofctl del-flows s5
```

---

## 🛑 Shutdown Procedure

### Step 1: Stop Mininet

**In Terminal 2 (Mininet CLI):**
```bash
mininet> exit
```

Or press `Ctrl+D`

### Step 2: Clean Up Mininet

```bash
sudo mn -c
```

**This command:**
- Removes all virtual switches
- Deletes virtual links
- Cleans up OpenFlow rules
- Frees up ports

### Step 3: Stop POX Controller

**In Terminal 1 (POX):**

Press `Ctrl+C`

**Expected output:**
```
^CINFO:core:Going down...
INFO:openflow.of_01:[...] disconnected
INFO:core:Down.
```

---

## 🔄 Quick Restart

If you want to run it again immediately:

```bash
# Terminal 1
cd ~/pox
./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra

# Terminal 2 (wait for POX to fully start)
sudo mn -c  # Clean up first
sudo python3 ~/mininet_topology.py
```

---

## 🐛 Common Issues & Solutions

### Issue 1: "Address already in use" (port 6633)

**Cause:** Previous POX instance still running

**Solution:**
```bash
sudo netstat -tlnp | grep 6633
sudo kill -9 <PID>
# Then restart POX
```

### Issue 2: "Address already in use" (port 8000)

**Cause:** HTTP API server still running

**Solution:**
```bash
sudo netstat -tlnp | grep 8000
sudo kill -9 <PID>
# Then restart POX
```

### Issue 3: Switches not connecting

**Cause:** Old Mininet processes running

**Solution:**
```bash
sudo mn -c
sudo killall controller
sudo fuser -k 6633/tcp
# Then restart both POX and Mininet
```

### Issue 4: Ping fails (100% packet loss)

**Cause:** Flows not installed correctly

**Solution:**
```bash
# In Mininet CLI:
mininet> sh ovs-ofctl dump-flows s3
# Check if flows exist

# If no flows, check POX terminal for errors
# Restart both POX and Mininet
```

### Issue 5: "module 'core' has no attribute 'openflow'"

**Cause:** Controller loaded before OpenFlow components

**Solution:**
- Make sure you're using the `controller_fixed_edge_ports.py` version
- Use the exact POX command: `./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra`

---

## 📊 Network Topology Reference

```
        H1 (10.0.0.1)
             |
            S3
           /  \
         S2    S5
           \  /
            S4
             |
        H2 (10.0.0.2)
```

**Switch IDs:**
- S2 = Switch 2
- S3 = Switch 3 (connected to H1)
- S4 = Switch 4 (connected to H2)
- S5 = Switch 5

**Paths:**
- **Primary:** H1 → S3 → S2 → S4 → H2 (length: 2 hops)
- **Backup:** H1 → S3 → S5 → S4 → H2 (length: 2 hops)

---

## 🎓 Understanding the Output

### When Dijkstra Runs

```
INFO:misc.controller_with_dijkstra:Computing path from S3 to S4...
INFO:misc.controller_with_dijkstra:Dijkstra found path: [3, 2, 4] (length: 2)
```

**This means:**
- Source: Switch 3 (connected to H1)
- Destination: Switch 4 (connected to H2)
- Path: [3, 2, 4] = S3 → S2 → S4
- Length: 2 hops between switches

### When Flows are Installed

```
INFO:misc.controller_with_dijkstra:Forward direction (H1 → H2):
INFO:misc.controller_with_dijkstra:  S3 → S2 via port 2
INFO:misc.controller_with_dijkstra:  S2 → S4 via port 2
INFO:misc.controller_with_dijkstra:Reverse direction (H2 → H1):
INFO:misc.controller_with_dijkstra:  S4 → S2 via port 1
INFO:misc.controller_with_dijkstra:  S2 → S3 via port 1
INFO:misc.controller_with_dijkstra:Installing edge flows:
INFO:misc.controller_with_dijkstra:  S3 → H1 via port 1
INFO:misc.controller_with_dijkstra:  S4 → H2 via port 2
```

**This means:**
- Forward flows installed for H1 → H2 traffic
- Reverse flows installed for H2 → H1 traffic
- Edge flows connect switches to hosts

---

## 📝 API Endpoints Reference

**Base URL:** `http://localhost:8000`

### POST /failure
Inject a link failure

**Example:**
```bash
curl -X POST http://localhost:8000/failure -d "a=3&b=2"
```

**Parameters:**
- `a` = First switch ID
- `b` = Second switch ID

### POST /restore
Restore a failed link

**Example:**
```bash
curl -X POST http://localhost:8000/restore -d "a=3&b=2"
```

### POST /status
Get current network status

**Example:**
```bash
curl -X POST http://localhost:8000/status -d ""
```

**Response includes:**
- `adjacency`: Current network topology
- `failed_links`: Set of currently failed links
- `connections`: List of connected switches

---

## 🎯 Test Scenarios

### Scenario 1: Single Link Failure
```bash
# 1. Verify initial connectivity
mininet> h1 ping -c 3 h2

# 2. Fail primary path (S3-S2)
curl -X POST http://localhost:8000/failure -d "a=3&b=2"

# 3. Verify failover to backup path
mininet> h1 ping -c 5 h2

# 4. Restore link
curl -X POST http://localhost:8000/restore -d "a=3&b=2"

# 5. Verify return to primary path
mininet> h1 ping -c 3 h2
```

### Scenario 2: Multiple Link Failures
```bash
# 1. Test initial state
mininet> h1 ping -c 2 h2

# 2. Fail backup path first
curl -X POST http://localhost:8000/failure -d "a=3&b=5"

# 3. Should still work (using primary)
mininet> h1 ping -c 2 h2

# 4. Now fail primary path too
curl -X POST http://localhost:8000/failure -d "a=3&b=2"

# 5. Network should be partitioned
mininet> h1 ping -c 2 h2
# Expected: Destination Host Unreachable

# 6. Restore one link
curl -X POST http://localhost:8000/restore -d "a=3&b=5"

# 7. Connectivity restored
mininet> h1 ping -c 2 h2

# 8. Clean up
curl -X POST http://localhost:8000/restore -d "a=3&b=2"
```

### Scenario 3: Continuous Ping During Failure
```bash
# 1. Start continuous ping in background
mininet> h1 ping h2 &

# 2. Inject failures and watch ping adapt
curl -X POST http://localhost:8000/failure -d "a=3&b=2"
# Watch ping continue with possible brief interruption

# 3. Restore
curl -X POST http://localhost:8000/restore -d "a=3&b=2"

# 4. Stop ping
mininet> fg
# Press Ctrl+C
```

---

## 💾 Backup Your Files

It's good practice to keep backups:

```bash
# Create a backup directory
mkdir -p ~/sdn_backup

# Backup controller
cp ~/pox/pox/misc/controller_with_dijkstra.py ~/sdn_backup/

# Backup topology
cp ~/mininet_topology.py ~/sdn_backup/

# Create a tarball
cd ~
tar -czf sdn_dijkstra_backup.tar.gz sdn_backup/

# To restore later:
# tar -xzf sdn_dijkstra_backup.tar.gz
```

---

## 📚 Additional Resources

### Learning More About Dijkstra's Algorithm
- Time Complexity: O(E log V) where E = edges, V = vertices
- Always finds shortest path if one exists
- Handles dynamic network changes

### POX Documentation
- Official Docs: https://noxrepo.github.io/pox-doc/html/
- OpenFlow 1.0 Specification
- POX Module Development Guide

### Mininet Resources
- Official Website: http://mininet.org/
- Walkthrough: http://mininet.org/walkthrough/
- API Reference: http://mininet.org/api/

---

## ✅ Quick Checklist

Before running, make sure:

- [ ] POX is installed in `~/pox`
- [ ] Controller file is in `~/pox/pox/misc/controller_with_dijkstra.py`
- [ ] Topology file is accessible (e.g., `~/mininet_topology.py`)
- [ ] No other controllers running on port 6633
- [ ] No other services using port 8000
- [ ] Mininet is cleaned up (`sudo mn -c`)

**Then execute in order:**
1. [ ] Start POX controller
2. [ ] Wait for "launched successfully" message
3. [ ] Start Mininet topology
4. [ ] Test basic connectivity
5. [ ] Test failure scenarios

---

## 🎉 Success Indicators

You know everything is working when you see:

✅ **POX Terminal:**
- "Dijkstra-based SDN Controller launched successfully"
- "Switch X connected" for all 4 switches
- "ADDED adjacency" for all links
- "Dijkstra found path: [3, 2, 4]"
- "Installing flows for path..."

✅ **Mininet Terminal:**
- `mininet>` prompt appears
- `h1 ping h2` shows 0% packet loss

✅ **Failure Test:**
- `curl` commands return success messages
- POX shows "LINK FAILURE DETECTED" and "Dijkstra found path: [3, 5, 4]"
- Ping still works after failure (using backup path)

---

**Keep this guide handy for future use!** 🚀

Last Updated: December 2024
