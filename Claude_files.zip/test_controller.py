#!/usr/bin/env python3
"""
Testing script for Dijkstra-based SDN Controller
This script helps you test the dynamic path computation
"""

import requests
import time
import subprocess
import sys

API_URL = "http://localhost:8000"

def print_banner(text):
    """Print a formatted banner"""
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60 + "\n")

def inject_failure(switch_a, switch_b):
    """Inject a link failure"""
    print(f"💥 Injecting failure on link S{switch_a} <-> S{switch_b}...")
    try:
        response = requests.post(f"{API_URL}/failure", data=f"a={switch_a}&b={switch_b}")
        print(f"   Response: {response.text}")
        return response.status_code == 200
    except Exception as e:
        print(f"   Error: {e}")
        return False

def restore_link(switch_a, switch_b):
    """Restore a failed link"""
    print(f"✅ Restoring link S{switch_a} <-> S{switch_b}...")
    try:
        response = requests.post(f"{API_URL}/restore", data=f"a={switch_a}&b={switch_b}")
        print(f"   Response: {response.text}")
        return response.status_code == 200
    except Exception as e:
        print(f"   Error: {e}")
        return False

def get_status():
    """Get current network status"""
    print("📊 Getting network status...")
    try:
        response = requests.post(f"{API_URL}/status", data="")
        print(f"   {response.text}")
        return True
    except Exception as e:
        print(f"   Error: {e}")
        return False

def test_connectivity():
    """Instructions for testing connectivity in Mininet"""
    print("🔍 To test connectivity, run in Mininet CLI:")
    print("   mininet> h1 ping -c 3 h2")
    print()

def run_demo():
    """Run a complete demonstration"""
    print_banner("DIJKSTRA SDN CONTROLLER - DEMO")
    
    print("This demo will:")
    print("1. Check initial connectivity (primary path: S3→S2→S4)")
    print("2. Inject failure on S3-S2 link")
    print("3. Verify traffic switches to backup path (S3→S5→S4)")
    print("4. Restore the link")
    print("5. Verify traffic returns to primary path")
    print()
    
    input("Press Enter to start demo...")
    
    # Step 1: Initial connectivity
    print_banner("Step 1: Initial Connectivity Test")
    print("Expected path: S3 → S2 → S4")
    test_connectivity()
    input("Press Enter after testing connectivity...")
    
    # Step 2: Inject failure
    print_banner("Step 2: Inject Link Failure (S3-S2)")
    inject_failure(3, 2)
    time.sleep(2)
    print("\nDijkstra should now compute alternative path: S3 → S5 → S4")
    test_connectivity()
    input("Press Enter after testing connectivity...")
    
    # Step 3: Check status
    print_banner("Step 3: Check Network Status")
    get_status()
    input("Press Enter to continue...")
    
    # Step 4: Restore link
    print_banner("Step 4: Restore Link (S3-S2)")
    restore_link(3, 2)
    time.sleep(2)
    print("\nDijkstra should now recompute optimal path: S3 → S2 → S4")
    test_connectivity()
    input("Press Enter after testing connectivity...")
    
    # Step 5: Final status
    print_banner("Step 5: Final Network Status")
    get_status()
    
    print_banner("DEMO COMPLETE!")
    print("You can continue testing with custom failures:")
    print("- Inject failure: python3 test_controller.py failure <switch_a> <switch_b>")
    print("- Restore link: python3 test_controller.py restore <switch_a> <switch_b>")
    print("- Get status: python3 test_controller.py status")

def run_test_scenario_1():
    """Test Scenario 1: Single link failure"""
    print_banner("Test Scenario 1: Single Link Failure")
    print("Testing primary path failure (S3-S2)...")
    
    print("\n1. Initial state - Primary path active")
    test_connectivity()
    input("Press Enter to inject failure...")
    
    print("\n2. Inject failure on S3-S2")
    inject_failure(3, 2)
    time.sleep(2)
    test_connectivity()
    input("Press Enter to restore...")
    
    print("\n3. Restore S3-S2")
    restore_link(3, 2)
    time.sleep(2)
    test_connectivity()
    print("\n✅ Scenario 1 complete!")

def run_test_scenario_2():
    """Test Scenario 2: Multiple link failures"""
    print_banner("Test Scenario 2: Multiple Link Failures")
    print("Testing network resilience with multiple failures...")
    
    print("\n1. Initial state")
    test_connectivity()
    input("Press Enter to inject first failure...")
    
    print("\n2. Inject failure on S3-S2 (primary path)")
    inject_failure(3, 2)
    time.sleep(2)
    test_connectivity()
    input("Press Enter to inject second failure...")
    
    print("\n3. Inject failure on S3-S5 (backup path)")
    inject_failure(3, 5)
    time.sleep(2)
    print("⚠️  Network should be partitioned - no path available!")
    test_connectivity()
    input("Press Enter to restore first link...")
    
    print("\n4. Restore S3-S5")
    restore_link(3, 5)
    time.sleep(2)
    test_connectivity()
    input("Press Enter to restore second link...")
    
    print("\n5. Restore S3-S2")
    restore_link(3, 2)
    time.sleep(2)
    test_connectivity()
    print("\n✅ Scenario 2 complete!")

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python3 test_controller.py demo           - Run full demonstration")
        print("  python3 test_controller.py scenario1      - Run test scenario 1")
        print("  python3 test_controller.py scenario2      - Run test scenario 2")
        print("  python3 test_controller.py failure <a> <b> - Inject failure on link a-b")
        print("  python3 test_controller.py restore <a> <b> - Restore link a-b")
        print("  python3 test_controller.py status         - Get network status")
        return
    
    command = sys.argv[1]
    
    if command == "demo":
        run_demo()
    elif command == "scenario1":
        run_test_scenario_1()
    elif command == "scenario2":
        run_test_scenario_2()
    elif command == "failure" and len(sys.argv) == 4:
        inject_failure(int(sys.argv[2]), int(sys.argv[3]))
    elif command == "restore" and len(sys.argv) == 4:
        restore_link(int(sys.argv[2]), int(sys.argv[3]))
    elif command == "status":
        get_status()
    else:
        print("Invalid command or arguments")
        main()

if __name__ == "__main__":
    main()
