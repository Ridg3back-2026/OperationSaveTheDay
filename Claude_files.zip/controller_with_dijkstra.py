from pox.core import core
import pox.openflow.discovery
from pox.lib.addresses import IPAddr
from pox.openflow import libopenflow_01 as of
from threading import Thread, Timer
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, unquote_plus
import heapq

log = core.getLogger()

H1_IP = "10.0.0.1"
H2_IP = "10.0.0.2"

connections = {}
adjacency = {}
failed_links = set()

host_to_switch = {
    IPAddr(H1_IP): 3,
    IPAddr(H2_IP): 4
}

def install_flow(conn, src, dst, out_port):
    """Install a flow rule on a switch"""
    fm = of.ofp_flow_mod()
    m = of.ofp_match()
    m.dl_type = 0x0800
    m.nw_src = IPAddr(src)
    m.nw_dst = IPAddr(dst)
    fm.match = m
    fm.actions.append(of.ofp_action_output(port=out_port))
    fm.idle_timeout = 30
    conn.send(fm)

def clear_flows(conn):
    """Clear all flows from a switch"""
    fm = of.ofp_flow_mod()
    fm.command = of.OFPFC_DELETE
    conn.send(fm)
    log.info("Cleared flows on switch %s" % conn.dpid)

def adjacency_add(link):
    """Add a link to the adjacency list"""
    a, b = link.dpid1, link.dpid2
    pa, pb = link.port1, link.port2
    adjacency.setdefault(a, {})[b] = pa
    adjacency.setdefault(b, {})[a] = pb
    log.info("ADDED adjacency: %s-%s (ports %s-%s)" % (a, b, pa, pb))

def adjacency_remove(link):
    """Remove a link from the adjacency list"""
    a, b = link.dpid1, link.dpid2
    if a in adjacency and b in adjacency[a]:
        del adjacency[a][b]
    if b in adjacency and a in adjacency[b]:
        del adjacency[b][a]
    log.warning("REMOVED adjacency: %s-%s" % (a, b))

def get_port(a, b):
    """Get the port number from switch a to switch b"""
    try:
        return adjacency[a][b]
    except:
        return None

def dijkstra(src, dst):
    """
    Find shortest path from src to dst using Dijkstra's algorithm
    Returns: list representing the path, or None if no path exists
    """
    if src == dst:
        return [src]
    
    # Priority queue: (distance, current_node, path)
    pq = [(0, src, [src])]
    visited = set()
    
    log.debug("Starting Dijkstra from %s to %s" % (src, dst))
    log.debug("Available adjacency: %s" % adjacency)
    log.debug("Failed links: %s" % failed_links)
    
    while pq:
        dist, current, path = heapq.heappop(pq)
        
        if current in visited:
            continue
        visited.add(current)
        
        log.debug("Visiting node %s, path so far: %s" % (current, path))
        
        # Found destination
        if current == dst:
            log.info("Dijkstra found path: %s (length: %d)" % (path, len(path) - 1))
            return path
        
        # Explore neighbors
        if current in adjacency:
            for neighbor in adjacency[current]:
                # Skip failed links
                link = (min(current, neighbor), max(current, neighbor))
                if link in failed_links:
                    log.debug("Skipping failed link %s-%s" % (current, neighbor))
                    continue
                
                if neighbor not in visited:
                    new_path = path + [neighbor]
                    heapq.heappush(pq, (dist + 1, neighbor, new_path))
                    log.debug("Added to queue: neighbor %s, path %s" % (neighbor, new_path))
    
    log.error("No path found between %s and %s" % (src, dst))
    return None

def apply_path(path):
    """
    Install flow rules along a path for bidirectional traffic
    """
    if not path or len(path) < 2:
        log.error("Invalid path: %s" % path)
        return False
    
    log.info("=" * 60)
    log.info("Installing flows for path: %s" % path)
    log.info("=" * 60)
    
    # Clear old flows first
    for sw in path:
        conn = connections.get(sw)
        if conn:
            clear_flows(conn)
    
    # Forward direction (H1 → H2)
    log.info("Forward direction (H1 → H2):")
    for i in range(len(path) - 1):
        sw = path[i]
        nxt = path[i + 1]
        conn = connections.get(sw)
        out_port = get_port(sw, nxt)
        
        if conn and out_port:
            install_flow(conn, H1_IP, H2_IP, out_port)
            log.info("  S%s → S%s via port %s" % (sw, nxt, out_port))
        else:
            log.error("  Failed to install flow on S%s (conn=%s, port=%s)" % (sw, conn, out_port))
    
    # Reverse direction (H2 → H1)
    log.info("Reverse direction (H2 → H1):")
    for i in range(len(path) - 1, 0, -1):
        sw = path[i]
        prev = path[i - 1]
        conn = connections.get(sw)
        out_port = get_port(sw, prev)
        
        if conn and out_port:
            install_flow(conn, H2_IP, H1_IP, out_port)
            log.info("  S%s → S%s via port %s" % (sw, prev, out_port))
        else:
            log.error("  Failed to install flow on S%s (conn=%s, port=%s)" % (sw, conn, out_port))
    
    # Install edge flows (hosts to switches)
    install_edge_flows(path)
    
    log.info("=" * 60)
    return True

def install_edge_flows(path):
    """
    Install flow rules for edge switches to reach hosts
    Dynamically determine which ports connect to hosts
    """
    log.info("Installing edge flows:")
    
    # First switch (S3) to H1
    first_sw = path[0]
    conn_first = connections.get(first_sw)
    if conn_first:
        # Find port to H1 - it's the port NOT in the adjacency list
        used_ports = set()
        if first_sw in adjacency:
            used_ports = set(adjacency[first_sw].values())
        
        # Get all ports on this switch
        all_ports = set(range(1, 10))  # Typical switch has ports 1-9
        available_ports = all_ports - used_ports
        
        if available_ports:
            h1_port = min(available_ports)  # Use lowest available port
            install_flow(conn_first, H2_IP, H1_IP, h1_port)
            log.info("  S%s → H1 via port %s" % (first_sw, h1_port))
        else:
            # Fallback to port 1
            install_flow(conn_first, H2_IP, H1_IP, 1)
            log.info("  S%s → H1 via port 1 (fallback)" % first_sw)
    
    # Last switch (S4) to H2
    last_sw = path[-1]
    conn_last = connections.get(last_sw)
    if conn_last:
        # Find port to H2 - it's the port NOT in the adjacency list
        used_ports = set()
        if last_sw in adjacency:
            used_ports = set(adjacency[last_sw].values())
        
        all_ports = set(range(1, 10))
        available_ports = all_ports - used_ports
        
        if available_ports:
            h2_port = min(available_ports)
            install_flow(conn_last, H1_IP, H2_IP, h2_port)
            log.info("  S%s → H2 via port %s" % (last_sw, h2_port))
        else:
            # Fallback to port 1
            install_flow(conn_last, H1_IP, H2_IP, 1)
            log.info("  S%s → H2 via port 1 (fallback)" % last_sw)

def compute_and_apply_path(src_switch, dst_switch):
    """
    Compute shortest path using Dijkstra and install flows
    """
    log.info("Computing path from S%s to S%s..." % (src_switch, dst_switch))
    
    path = dijkstra(src_switch, dst_switch)
    
    if path:
        return apply_path(path)
    else:
        log.error("Cannot establish path - network may be partitioned")
        return False

def handle_failure(a, b):
    """Handle link failure by recomputing path"""
    log.warning("=" * 60)
    log.warning("LINK FAILURE DETECTED: %s <-> %s" % (a, b))
    log.warning("=" * 60)
    
    failed_links.add((min(a, b), max(a, b)))
    
    # Recompute path dynamically
    log.info("Recomputing path to avoid failed link...")
    compute_and_apply_path(3, 4)

def restore_link(a, b):
    """Restore link and recompute optimal path"""
    log.info("=" * 60)
    log.info("LINK RESTORED: %s <-> %s" % (a, b))
    log.info("=" * 60)
    
    failed_links.discard((min(a, b), max(a, b)))
    
    # Recompute optimal path
    log.info("Recomputing optimal path...")
    compute_and_apply_path(3, 4)

def _handle_LinkEvent(event):
    """Handle link up/down events from discovery"""
    link = event.link
    if event.added:
        adjacency_add(link)
        # Recompute path when new links are discovered
        Timer(1, lambda: compute_and_apply_path(3, 4)).start()
    else:
        adjacency_remove(link)
        # Mark as failed and recompute
        a, b = link.dpid1, link.dpid2
        failed_links.add((min(a, b), max(a, b)))
        compute_and_apply_path(3, 4)

def _handle_ConnectionUp(event):
    """Handle switch connection"""
    dpid = event.connection.dpid
    connections[dpid] = event.connection
    log.info("Switch %s connected" % dpid)
    
    # If all switches are connected, compute initial path
    if len(connections) >= 4:  # We have 4 switches
        Timer(2, lambda: compute_and_apply_path(3, 4)).start()

def _handle_PacketIn(event):
    """Handle packet-in events (currently unused)"""
    pass

class FailureRequestHandler(BaseHTTPRequestHandler):
    """HTTP handler for external failure injection"""
    
    def do_POST(self):
        try:
            length_header = self.headers.get('Content-Length')
            if not length_header:
                self.send_response(411)
                self.end_headers()
                self.wfile.write(b"Missing Content-Length")
                return

            length = int(length_header)
            raw = self.rfile.read(length)
            body = raw.decode('utf-8', 'ignore')
            params = parse_qs(unquote_plus(body))
            a = int(params.get("a", [""])[0])
            b = int(params.get("b", [""])[0])

            if self.path == "/failure":
                handle_failure(a, b)
                response = f"Failure injected on {a}-{b}\n".encode()
            elif self.path == "/restore":
                restore_link(a, b)
                response = f"Link restored on {a}-{b}\n".encode()
            elif self.path == "/status":
                # Show current network status
                status = {
                    "adjacency": str(adjacency),
                    "failed_links": str(failed_links),
                    "connections": list(connections.keys())
                }
                response = str(status).encode()
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Invalid endpoint. Use /failure, /restore, or /status\n")
                return

            self.send_response(200)
            self.end_headers()
            self.wfile.write(response)

        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(f"Server error: {e}\n".encode())

    def log_message(self, format, *args):
        """Suppress HTTP server logs"""
        return

def start_http_server():
    """Start HTTP server for failure injection API"""
    try:
        server = HTTPServer(("0.0.0.0", 8000), FailureRequestHandler)
        log.info("External Failure API Server running on port 8000")
        log.info("Endpoints: /failure, /restore, /status")
        server.serve_forever()
    except Exception as e:
        log.error(f"HTTP server failed to start: {e}")

def _register_handlers():
    """Register event handlers after OpenFlow is loaded"""
    try:
        # Check if openflow components are available
        if not hasattr(core, 'openflow'):
            log.debug("Waiting for openflow component...")
            Timer(0.5, _register_handlers).start()
            return
        
        if not hasattr(core, 'openflow_discovery'):
            log.debug("Waiting for openflow_discovery component...")
            Timer(0.5, _register_handlers).start()
            return
        
        # Both components are available, register handlers
        core.openflow.addListenerByName("ConnectionUp", _handle_ConnectionUp)
        core.openflow.addListenerByName("PacketIn", _handle_PacketIn)
        core.openflow_discovery.addListenerByName("LinkEvent", _handle_LinkEvent)
        
        log.info("=" * 60)
        log.info("Dijkstra-based SDN Controller launched successfully")
        log.info("=" * 60)
    except Exception as e:
        log.error("Failed to register handlers: %s" % e)
        log.debug("Will retry in 0.5 seconds...")
        Timer(0.5, _register_handlers).start()

def launch():
    """Launch the controller"""
    # Start HTTP API server
    thread = Thread(target=start_http_server)
    thread.daemon = True
    thread.start()
    
    # Wait for POX to fully initialize, then register handlers
    Timer(2, _register_handlers).start()
