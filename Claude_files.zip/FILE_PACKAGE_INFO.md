# 📦 Dijkstra SDN Controller - File Package

## Required Files

You need these **2 essential files** to run the system:

### 1. Controller File
**Filename:** `controller_with_dijkstra.py`
**Location:** Must be placed in `~/pox/pox/misc/controller_with_dijkstra.py`
**Purpose:** POX controller implementing Dijkstra's shortest path algorithm

### 2. Topology File
**Filename:** `mininet_topology.py`
**Location:** Can be placed anywhere (recommended: `~/mininet_topology.py`)
**Purpose:** Creates the Mininet network with 4 switches and 2 hosts

---

## Documentation Files (Reference Only)

### 3. Setup Guide
**Filename:** `SETUP_GUIDE.md`
**Purpose:** Complete instructions for installation, execution, and troubleshooting

### 4. Quick Reference
**Filename:** `QUICK_REFERENCE.md`
**Purpose:** One-page quick reference for rapid execution

### 5. Comparison Document
**Filename:** `STATIC_VS_DIJKSTRA.md`
**Purpose:** Detailed comparison between static and dynamic approaches

### 6. Complete Guide
**Filename:** `COMPLETE_GUIDE.md`
**Purpose:** Comprehensive documentation with examples and use cases

---

## Installation Commands

After downloading the files, run these commands:

```bash
# Copy controller to POX directory
cp controller_with_dijkstra.py ~/pox/pox/misc/

# Copy topology to home directory
cp mininet_topology.py ~/

# Set permissions
chmod 644 ~/pox/pox/misc/controller_with_dijkstra.py
chmod +x ~/mininet_topology.py
```

---

## Verification

Check that files are in the correct location:

```bash
# Check controller
ls -la ~/pox/pox/misc/controller_with_dijkstra.py

# Check topology
ls -la ~/mininet_topology.py

# Verify POX can find it
cd ~/pox
./pox.py --help | grep controller_with_dijkstra
```

---

## Quick Execution (After Installation)

```bash
# Terminal 1: Start Controller
cd ~/pox
./pox.py openflow.of_01 --port=6633 openflow.discovery misc.controller_with_dijkstra

# Terminal 2: Start Mininet (after controller is ready)
sudo python3 ~/mininet_topology.py

# Terminal 2: Test
mininet> h1 ping -c 3 h2

# Terminal 3: Test Failover
curl -X POST http://localhost:8000/failure -d "a=3&b=2"
```

---

## File Sizes (Approximate)

- `controller_with_dijkstra.py` - ~10 KB
- `mininet_topology.py` - ~2 KB
- `SETUP_GUIDE.md` - ~25 KB
- `QUICK_REFERENCE.md` - ~3 KB
- `STATIC_VS_DIJKSTRA.md` - ~15 KB
- `COMPLETE_GUIDE.md` - ~30 KB

---

## Key Features in the Controller

✅ Dynamic path computation using Dijkstra's algorithm
✅ Automatic failover when links fail
✅ Bidirectional flow installation
✅ HTTP API for failure injection (port 8000)
✅ Real-time path recomputation
✅ Support for multiple simultaneous failures
✅ Detailed logging for debugging

---

## Support

If you encounter issues:
1. Check `SETUP_GUIDE.md` - Section: "Common Issues & Solutions"
2. Verify all files are in correct locations
3. Ensure ports 6633 and 8000 are not in use
4. Run cleanup: `sudo mn -c`

---

## Version Information

- **Controller Version:** 2.0 (Dijkstra-based, POX compatible)
- **POX Compatibility:** 0.7.0 (gar) and later
- **Python Version:** 3.6+
- **Mininet Version:** 2.2.2 and later
- **Last Updated:** December 2024

---

**All files are available in the outputs directory!**
