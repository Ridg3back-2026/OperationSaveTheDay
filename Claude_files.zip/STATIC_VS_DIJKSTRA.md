# Static vs Dijkstra: Complete Comparison

## Side-by-Side Code Comparison

### 1. Path Definition

**Static Approach:**
```python
# Hardcoded paths
PRIMARY_PATH = [3, 2, 4]
BACKUP_PATH = [3, 5, 4]

def handle_failure(a, b):
    failed_links.add((min(a, b), max(a, b)))
    apply_path(BACKUP_PATH)  # Always use predefined backup
```

**Dijkstra Approach:**
```python
# No hardcoded paths!

def dijkstra(src, dst):
    """Dynamically compute shortest path"""
    pq = [(0, src, [src])]
    visited = set()
    
    while pq:
        dist, current, path = heapq.heappop(pq)
        if current == dst:
            return path
        # Explore neighbors, avoiding failed links...
    return None

def handle_failure(a, b):
    failed_links.add((min(a, b), max(a, b)))
    compute_and_apply_path(3, 4)  # Recompute dynamically
```

---

### 2. Bidirectional Flow Installation

**Static Approach (INCORRECT):**
```python
def apply_path(path):
    for i in range(len(path) - 1):
        sw = path[i]
        nxt = path[i + 1]
        out_port = get_port(sw, nxt)
        
        # BUG: Both directions use same port!
        install_flow(conn, H1_IP, H2_IP, out_port)
        install_flow(conn, H2_IP, H1_IP, out_port)  # ❌ WRONG
```

**Dijkstra Approach (CORRECT):**
```python
def apply_path(path):
    # Forward: H1 → H2
    for i in range(len(path) - 1):
        sw, nxt = path[i], path[i + 1]
        out_port = get_port(sw, nxt)
        install_flow(conn, H1_IP, H2_IP, out_port)  # ✅ Correct direction
    
    # Reverse: H2 → H1
    for i in range(len(path) - 1, 0, -1):
        sw, prev = path[i], path[i - 1]
        out_port = get_port(sw, prev)  # Different port!
        install_flow(conn, H2_IP, H1_IP, out_port)  # ✅ Correct direction
```

---

### 3. Handling Multiple Failures

**Static Approach:**
```python
# Can only handle specific failure
def handle_failure(a, b):
    if (a, b) == (3, 2) or (a, b) == (2, 3):
        apply_path(BACKUP_PATH)  # Switch to [3, 5, 4]
    else:
        # What if S5-S4 fails? No solution!
        pass
```

**Dijkstra Approach:**
```python
# Handles ANY failure
def handle_failure(a, b):
    failed_links.add((min(a, b), max(a, b)))
    path = dijkstra(3, 4)  # Finds best available path
    if path:
        apply_path(path)
    else:
        log.error("Network partitioned - no path exists")
```

---

## Real-World Test Scenarios

### Scenario A: Primary Link Fails (S3-S2)

**Static Controller:**
```
Initial:  [3, 2, 4] ✅
Failure:  [3, 5, 4] ✅ (switches to backup)
Result:   Works, but only because we predicted this failure
```

**Dijkstra Controller:**
```
Initial:   dijkstra(3,4) → [3, 2, 4] ✅
Failure:   dijkstra(3,4) → [3, 5, 4] ✅ (computes alternative)
Result:    Works, adapts to any topology
```

---

### Scenario B: Backup Link Fails (S3-S5)

**Static Controller:**
```
Initial:  [3, 2, 4] ✅
Failure:  [3, 2, 4] ✅ (primary still works)
Now fail S3-S2 too:
          [3, 5, 4] ❌ (backup is down! Network broken)
Result:   FAILS - no connectivity
```

**Dijkstra Controller:**
```
Initial:   dijkstra(3,4) → [3, 2, 4] ✅
Failure:   dijkstra(3,4) → [3, 2, 4] ✅ (backup not needed)
Now fail S3-S2 too:
           dijkstra(3,4) → None ✅ (correctly detects partition)
Result:    Properly detects no path exists
```

---

### Scenario C: Different Topology

Imagine we add switch S6 with links: S3-S6-S2

**Static Controller:**
```
Code needs manual update:
PRIMARY_PATH = [3, 2, 4]
BACKUP_PATH_1 = [3, 5, 4]
BACKUP_PATH_2 = [3, 6, 2, 4]  # Must add manually

# Must also update failure logic:
if s3_s2_failed and s3_s5_failed:
    use BACKUP_PATH_2
elif s3_s2_failed:
    use BACKUP_PATH_1
# Gets complex quickly!
```

**Dijkstra Controller:**
```
# No code changes needed!
# Topology discovered automatically
# Dijkstra finds best path through S6 automatically

dijkstra(3, 4) → [3, 6, 2, 4] ✅ (finds it automatically)
```

---

## Performance Comparison

### Time Complexity

**Static Approach:**
- Path lookup: **O(1)** - instant
- Flow installation: **O(n)** where n = path length
- Total: **O(n)**

**Dijkstra Approach:**
- Dijkstra computation: **O(E log V)**
  - E = edges (links)
  - V = vertices (switches)
- Flow installation: **O(n)**
- Total: **O(E log V + n)**

**For this topology:**
- Static: O(3) ≈ 3 operations
- Dijkstra: O(6 log 4 + 3) ≈ 15 operations

**Verdict:** Static is ~5x faster, but this is negligible (microseconds vs milliseconds)

---

### Memory Usage

**Static Approach:**
```python
PRIMARY_PATH = [3, 2, 4]      # 3 integers = 24 bytes
BACKUP_PATH = [3, 5, 4]       # 3 integers = 24 bytes
Total: ~50 bytes
```

**Dijkstra Approach:**
```python
adjacency = {
    3: {2: 2, 5: 3},
    2: {3: 1, 4: 2},
    4: {2: 1, 5: 2},
    5: {3: 1, 4: 1}
}
# Dictionary overhead + integers
Total: ~200-300 bytes
```

**Verdict:** Static uses less memory, but difference is trivial

---

## Scalability Analysis

### Small Network (4 switches)

**Static:**
- ✅ Very fast
- ✅ Simple to understand
- ❌ Limited to predefined failures
- ❌ Must manually code each path

**Dijkstra:**
- ✅ Handles any failure
- ✅ Automatic adaptation
- ⚠️  Slight overhead (negligible)

**Winner:** Dijkstra (flexibility > minor performance gain)

---

### Large Network (100+ switches)

**Static:**
- ❌ Impossible to predefine all paths
- ❌ Exponential complexity for programmer
- ❌ Each topology change needs code update
- ❌ Cannot handle unforeseen failures

**Dijkstra:**
- ✅ Scales automatically
- ✅ No manual path configuration
- ✅ Handles any topology
- ✅ Computation time still acceptable (ms)

**Winner:** Dijkstra (only practical solution)

---

## Real-World Use Cases

### When to Use Static Paths

1. **Hardened Infrastructure:**
   - Military/critical systems
   - Known failure modes
   - Predictable traffic patterns
   - Example: Redundant power grid with 2 paths

2. **Regulatory Requirements:**
   - Traffic MUST follow specific routes
   - Compliance mandates certain paths
   - Example: Financial networks with geographic constraints

3. **Deterministic Behavior:**
   - Need guaranteed latency
   - Avoid path computation delay
   - Example: Real-time control systems

---

### When to Use Dijkstra

1. **Dynamic Networks:**
   - Cloud data centers
   - ISP backbone networks
   - Campus networks
   - Any topology that changes

2. **Resilience Priority:**
   - Must survive multiple failures
   - High availability requirement
   - Example: Hospital network

3. **Large Scale:**
   - 10+ switches
   - Complex mesh topologies
   - Many possible paths
   - Example: Enterprise WAN

4. **Development/Testing:**
   - Topology still evolving
   - Experimenting with designs
   - Educational purposes

---

## Feature Comparison Matrix

| Feature | Static | Dijkstra |
|---------|--------|----------|
| Setup Complexity | ⭐⭐⭐⭐⭐ Very Easy | ⭐⭐⭐ Moderate |
| Runtime Speed | ⭐⭐⭐⭐⭐ Instant | ⭐⭐⭐⭐ Very Fast |
| Handles Single Failure | ⭐⭐⭐⭐⭐ Yes | ⭐⭐⭐⭐⭐ Yes |
| Handles Multiple Failures | ⭐⭐ Limited | ⭐⭐⭐⭐⭐ Yes |
| Topology Changes | ⭐ Needs Code | ⭐⭐⭐⭐⭐ Automatic |
| Scalability | ⭐⭐ Poor | ⭐⭐⭐⭐⭐ Excellent |
| Path Optimality | ⭐⭐⭐ Depends | ⭐⭐⭐⭐⭐ Guaranteed |
| Debugging | ⭐⭐⭐⭐⭐ Simple | ⭐⭐⭐ Moderate |
| Learning Value | ⭐⭐⭐ Good | ⭐⭐⭐⭐⭐ Excellent |

---

## Migration Path

### From Static to Dijkstra

If you have a static controller, here's how to migrate:

**Step 1: Add Dijkstra Function**
```python
import heapq

def dijkstra(src, dst):
    # Copy implementation from dijkstra controller
    pass
```

**Step 2: Replace Static Paths**
```python
# Old:
# apply_path(PRIMARY_PATH)

# New:
path = dijkstra(3, 4)
if path:
    apply_path(path)
```

**Step 3: Update Failure Handling**
```python
# Old:
def handle_failure(a, b):
    apply_path(BACKUP_PATH)

# New:
def handle_failure(a, b):
    failed_links.add((min(a, b), max(a, b)))
    compute_and_apply_path(3, 4)
```

**Step 4: Test**
```bash
# Verify same behavior for known failures
# Test additional failure scenarios
```

---

## Algorithm Comparison

### Static Selection
```
Input: Failure on link (a, b)
Algorithm:
  1. IF (a,b) == (3,2):
       RETURN BACKUP_PATH
  2. ELSE:
       RETURN PRIMARY_PATH

Time: O(1)
Space: O(1)
```

### Dijkstra's Algorithm
```
Input: Source S, Destination D, Failed Links F
Algorithm:
  1. Initialize priority queue with (0, S, [S])
  2. WHILE queue not empty:
       a. Pop (dist, node, path) with smallest dist
       b. IF node == D:
            RETURN path
       c. FOR each neighbor of node:
            IF edge not in F AND neighbor not visited:
              Add (dist+1, neighbor, path+[neighbor]) to queue
  3. RETURN None (no path)

Time: O(E log V)
Space: O(V)
```

---

## Conclusion

### The Verdict

**For Learning:** Use Dijkstra ✅
- Teaches graph algorithms
- Shows real SDN principles
- Industry-relevant approach

**For Production (small network):** Either works
- Static if requirements are fixed
- Dijkstra if flexibility needed

**For Production (large network):** Use Dijkstra ✅
- Only practical solution
- Industry standard
- Proven at scale

---

### Best Practice Recommendation

```python
# Hybrid Approach (Best of Both Worlds)
PREFERRED_PATH = [3, 2, 4]  # Hint for Dijkstra

def dijkstra_with_preference(src, dst, preferred=None):
    """
    Compute shortest path, but prefer specific path
    if it has equal length
    """
    paths = find_all_shortest_paths(src, dst)
    
    if preferred and preferred in paths:
        return preferred
    else:
        return paths[0]  # Any shortest path
```

This gives you:
- ✅ Flexibility of Dijkstra
- ✅ Predictability of static paths
- ✅ Best of both worlds

---

**Summary:** For educational purposes and real-world applications, Dijkstra's approach is superior. The minimal performance overhead is worth the massive gain in flexibility and robustness.
